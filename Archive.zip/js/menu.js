
screenWidth = window.screen.width;
screenHeight = window.screen.height;


  $(document).ready(function () {
    $(".button-collapse").sideNav({
      menuWidth: 300,
      closeOnClick: true,
      edge: 'right', // <--- CHECK THIS OUT
    });
  });

window.addEventListener("scroll", function(){
  var indicator = document.querySelectorAll(".indicator");
  if (document.body.scrollTop > (3.3 * (screenHeight/5)) || document.documentElement.scrollTop > (3.3 * (screenHeight/5))) {
    document.querySelector(".navbar-color").style.backgroundImage = " url(images/landingBKG.svg)";
  } else {
    document.querySelector(".navbar-color").style.backgroundImage = "";
  }
    if (document.body.scrollTop > (1 * (screenHeight/5)) || document.documentElement.scrollTop > (1 * (screenHeight/5))) {
      document.querySelector(".icon-scroll").style.opacity = "0";
      document.querySelector(".indicator.active").style.background = "rgba(0,0,0,0.5)";
      for(i=0; i<indicator.length; i++){
        indicator[i].style.borderColor = "rgba(0,0,0,1)";
      }
    } else {
      document.querySelector(".icon-scroll").style.opacity = "1";
      document.querySelector(".indicator.active").style.background = "rgba(255,255,255,0.5)";
      for(i=0; i<indicator.length; i++){
        indicator[i].style.borderColor = "rgba(255,255,255,1)";
      }
    }
});
